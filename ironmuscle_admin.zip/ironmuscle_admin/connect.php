<?php 
$link=mysqli_connect("localhost","root","","gymsysdb")or die("Não foi possível realizar a conexão...");
	
?>