
<ul id="main-menu" class="" >
			
    <li id="dash"><a href="index.php"><i class="entypo-gauge"></i><span>Painel de Controlo</span></a></li>
                
	<li id="regis"><a href="new_entry.php"><i class="entypo-user-add"></i><span>Novo Registo</span></a>                
				
	<li id="paymnt"><a href="payments.php"><i class="entypo-star"></i><span>Pagamentos</span></a></li>

	<li class="" id="hassubopen"><a href="#" onclick="memberExpand(1)"><i class="entypo-users"></i><span>Clientes</span></a>
		<ul id="memExpand">
			<li class="active">
				<a href="view_mem.php"><span>Editar Clientes</span></a></li>

			<li><a href="table_view.php"><span>Visualizar Clientes</span></a></li>
		</ul>
	</li>

	<li id="health_status"><a href="new_health_status.php"><i class="entypo-user-add"></i><span>Status de Saúde</span></a> 	

		<li class="" id="planhassubopen"><a href="#" onclick="memberExpand(2)"><i class="entypo-quote"></i><span>Planos</span></a>

		<ul id="planExpand">
			<li class="active">
				<a href="new_plan.php"><span>Novo Plano</span></a></li>

			<li><a href="view_plan.php"><span>Editar detalhes do plano</span></a></li>
		</ul>

	<li class="" id="overviewhassubopen"><a href="#" onclick="memberExpand(3)"><i class="entypo-box"></i><span>Visão Geral</span></a>

		<ul id="overviewExpand">
			<li class="active">
				<a href="over_members_month.php"><span>Clientes por Mês</span></a>
			</li>

			<li>
				<a href="over_members_year.php"><span>Clientes por Ano</span></a>
			</li>

			<li>
				<a href="revenue_month.php"><span>Lucro por Mês</span></a>
			</li>			

		</ul>

	<li class="" id="routinehassubopen"><a href="#" onclick="memberExpand(4)"><i class="entypo-alert"></i><span>Rotina de exercícios</span></a>

		<ul id="routineExpand">
			<li class="active">
				<a href="addroutine.php"><span>Adicionar rotina</span></a>
			</li>

			<li>
				<a href="editroutine.php"><span>Editar Rotina</span></a>
			</li>

			<li>
				<a href="viewroutine.php"><span>Visualizar Rotina</span></a>
			</li>

		</ul>

	</li>

	<li id="adminprofile"><a href="more-userprofile.php"><i class="entypo-folder"></i><span>Perfil</span></a></li>

	<li><a href="logout.php"><i class="entypo-logout"></i><span>Sair</span></a></li>

</ul>	
